- v1.99
  - Fixes keys F13-F24 not being bindable.

- v1.98
  - Recompiled to fix any potential issues with the latest game update.

- v1.97
  - Adds automatic clean up for old unused Infinity Hammer binds.

- v1.96
  - Adds a workaround for the game swapping Mouse4 and Mouse5 keys.
  - Fixes fly down not working if keys overlap with fly up keys.

- v1.95
  - Adds a new command `message` to broadcast a message to specific players.
  - Overhauls the bind system to support more features (and simplify implementation).
  - Removes the setting "Mouse wheel bind key" as obsolete.
  - Removes the custom `resetskill` command as obsolete.

- v1.94
  - Adds a new setting "Server chat name" to change the name of the server chat.
